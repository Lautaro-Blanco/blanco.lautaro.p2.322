package app;

import config.RutasArchivos;
import java.io.IOException;
import model.CasoHawkins;
import model.ClasificacionCaso;
import persistence.RegistroHawkins;

public class Main {

    public static void main(String[] args) {

        try {
            RegistroHawkins<CasoHawkins> registro = new RegistroHawkins<>();

            registro.agregar(new CasoHawkins(1, "Apertura cerca del laboratorio", "Dr. Brenner", ClasificacionCaso.APERTURA_DIMENSIONAL));
            registro.agregar(new CasoHawkins(2, "Actividad psíquica elevada", "Dr. Owens", ClasificacionCaso.SUJETO_PSIQUICO));
            registro.agregar(new CasoHawkins(3, "Rastros de entidad en Hawkins", "Jim Hopper", ClasificacionCaso.ENTIDAD_HOSTIL));
            registro.agregar(new CasoHawkins(4, "Señales electromagnéticas inusuales", "Nancy Wheeler", ClasificacionCaso.FENOMENO_ELECTROMAGNETICO));
            registro.agregar(new CasoHawkins(5, "Desaparición de joven en bosque", "Joyce Byers", ClasificacionCaso.DESAPARICION));

            System.out.println("Casos registrados:");
            registro.paraCadaElemento(System.out::println);

            System.out.println("\nCasos tipo SUJETO_PSIQUICO:");
            registro.filtrar(c -> c.getClasificacion() == ClasificacionCaso.SUJETO_PSIQUICO)
                    .forEach(System.out::println);

            System.out.println("\nCasos que contienen 'portal':");
            registro.filtrar(c -> c.getTitulo().toLowerCase().contains("portal"))
                    .forEach(System.out::println);

            System.out.println("\nCasos ordenados por ID:");
            registro.ordenar();
            registro.paraCadaElemento(System.out::println);

            System.out.println("\nCasos ordenados por título:");
            registro.ordenar((c1, c2) -> c1.getTitulo().compareTo(c2.getTitulo()));
            registro.paraCadaElemento(System.out::println);

            registro.guardarEnArchivo(RutasArchivos.getRutaBINString());

            RegistroHawkins<CasoHawkins> cargado = new RegistroHawkins<>();
            cargado.cargarDesdeArchivo(RutasArchivos.getRutaBINString());

            System.out.println("\nCasos cargados desde archivo binario:");
            cargado.paraCadaElemento(System.out::println);

            registro.guardarEnCSV(RutasArchivos.getRutaCSVString());

            cargado.cargarDesdeCSV(RutasArchivos.getRutaCSVString(), CasoHawkins::fromCSV);

            System.out.println("\nCasos cargados desde archivo CSV:");
            cargado.paraCadaElemento(System.out::println);

        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}
