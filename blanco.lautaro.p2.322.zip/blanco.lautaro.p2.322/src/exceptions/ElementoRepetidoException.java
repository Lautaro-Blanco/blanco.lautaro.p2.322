package exceptions;

public class ElementoRepetidoException extends RuntimeException {

    private static final String MENSAJE = "El caso ya existe en el registro";

    public ElementoRepetidoException(String mensaje) {
        super(mensaje);
    }

    public ElementoRepetidoException() {
        this(MENSAJE);
    }
}
