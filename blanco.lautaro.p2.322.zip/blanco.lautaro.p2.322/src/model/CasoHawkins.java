package model;

import java.io.Serializable;

public class CasoHawkins implements Comparable<CasoHawkins>, CSVSerializable, Serializable {

    private final int id;
    private final String titulo;
    private final String investigador;
    private final ClasificacionCaso clasificacion;
    private static final long serialVersionUID = 1L;

    public CasoHawkins(int id, String titulo, String investigador, ClasificacionCaso clasificacion) {
        this.id = id;
        this.titulo = titulo;
        this.investigador = investigador;
        this.clasificacion = clasificacion;
    }

    public int getId() {
        return id;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getInvestigador() {
        return investigador;
    }

    public ClasificacionCaso getClasificacion() {
        return clasificacion;
    }

    @Override
    public int compareTo(CasoHawkins otro) {
        return Integer.compare(this.id, otro.id);
    }

    @Override
    public String toCSV() {
        return id + "," + titulo + "," + investigador + "," + clasificacion;
    }

    public static CasoHawkins fromCSV(String linea) {
        String[] partes = linea.split(",", -1);

        if (partes.length != 4) {
            throw new IllegalArgumentException("Formato CSV invalido: " + linea);
        }

        try {
            int id = Integer.parseInt(partes[0]);
            String titulo = partes[1];
            String investigador = partes[2];
            ClasificacionCaso clasificacion = ClasificacionCaso.valueOf(partes[3].toUpperCase());

            return new CasoHawkins(id, titulo, investigador, clasificacion);
        } catch (Exception e) {
            throw new IllegalArgumentException("Error al parsear linea CSV: " + linea, e);
        }
    }

    @Override
    public String toString() {
        return "CasoHawkins{" + "id=" + id + ", titulo=" + titulo + ", investigador=" + investigador + ", clasificacion=" + clasificacion + '}';
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || !(obj instanceof CasoHawkins c)) {
            return false;
        }
        return this.id == c.id;
    }

    @Override
    public int hashCode() {
        return Integer.hashCode(id);
    }
}
