package persistence;

import exceptions.ElementoRepetidoException;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import model.CSVSerializable;

public class RegistroHawkins<T extends CSVSerializable> implements Serializable {

    private static final long serialVersionUID = 1L;
    private List<T> elementos = new ArrayList<>();

    public void agregar(T elemento) {
        validarRepetido(elemento);
        validarNull(elemento);
        elementos.add(elemento);
    }

    public T obtener(int indice) {
        validarIndice(indice);
        return elementos.get(indice);
    }

    public void eliminar(int indice) {
        validarIndice(indice);
        elementos.remove(indice);
    }

    public List<T> filtrar(Predicate<T> criterio) {
        validarNull(criterio);
        List<T> resultado = new ArrayList<>();
        for (T elem : elementos) {
            if (criterio.test(elem)) {
                resultado.add(elem);
            }
        }
        return resultado;
    }

    public void ordenar(Comparator<T> comparador) {
        validarNull(comparador);
        elementos.sort(comparador);
    }

    public void ordenar() {
        if (elementos.isEmpty()) {
            throw new IllegalStateException("No hay casos para ordenar");
        }
        if (elementos.get(0) instanceof Comparable) {
            elementos.sort((Comparator<? super T>) Comparator.naturalOrder());
        } else {
            throw new IllegalStateException("Los casos no se pueden ordenar de forma natural");
        }
    }

    public void paraCadaElemento(Consumer<T> accion) {
        validarNull(accion);
        elementos.forEach(accion);
    }

    public void guardarEnArchivo(String path) throws IOException {
        if (elementos.isEmpty()) {
            throw new IllegalStateException("No hay casos para guardar");
        }
        try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(path))) {
            salida.writeObject(elementos);
        }
    }

    public void cargarDesdeArchivo(String path) throws IOException, ClassNotFoundException {
        try (ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(path))) {
            elementos = (List<T>) entrada.readObject();
        }
    }

    public void guardarEnCSV(String path) throws IOException {
        if (elementos.isEmpty()) {
            throw new IllegalStateException("No hay casos para exportar");
        }
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(path))) {
            for (T elem : elementos) {
                writer.write(elem.toCSV());
                writer.newLine();
            }
        }
    }

    public void cargarDesdeCSV(String path, Function<String, T> constructor) throws IOException {
        if (constructor == null) {
            throw new NullPointerException("El constructor no puede ser nulo");
        }
        try (BufferedReader reader = new BufferedReader(new FileReader(path))) {
            elementos.clear();
            String linea;
            while ((linea = reader.readLine()) != null) {
                if (!linea.isEmpty()) {
                    agregar(constructor.apply(linea));
                }
            }
        }
    }

    private void validarRepetido(T elemento) {
        if (elementos.contains(elemento)) {
            throw new ElementoRepetidoException();
        }
    }

    private void validarNull(Object obj) {
        if (obj == null) {
            throw new NullPointerException("El valor no puede ser nulo");
        }
    }

    private void validarIndice(int indice) {
        if (indice >= elementos.size() || indice < 0) {
            throw new IndexOutOfBoundsException("Indice de caso invalido: " + indice);
        }
    }
}
